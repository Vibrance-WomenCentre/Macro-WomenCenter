package com.example.womencenter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Profile_Consult : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_consult)
    }
}